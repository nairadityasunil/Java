package ArrayDeque1;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDeque1 {
    public static void main(String[] args) {
        Deque<Integer> d1 = new ArrayDeque<>();
        d1.add(6);
        d1.add(56); // Add at end of the deque
    }
}

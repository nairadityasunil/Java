    // obj.create();
        // obj.insert(1,"iPhone",122000,"Electronics");
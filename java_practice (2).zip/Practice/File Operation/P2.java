// Character Stream


// Error is of package . can be ignored

import java.util.HashSet;

public class Hashset1{
    public static void main(String[] args) {
        HashSet <Integer> h1 = new HashSet<>();
        h1.add(6);
        h1.add(8);
        h1.add(3);
        h1.add(11);
        h1.add(11);
        System.out.println(h1);
    }
}